package game;

public enum Movements {
	DOWN, LEFT, RIGHT, ROTATION, PAUSE;
}
