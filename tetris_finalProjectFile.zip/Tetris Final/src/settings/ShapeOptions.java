package settings;

public enum ShapeOptions {
TETRAMINO, TRIMINO, BOTH;
}
