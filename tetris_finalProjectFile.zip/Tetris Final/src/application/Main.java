package application;


import gui.StartWindow;

public class Main {  
	 
	public static void main(String[] args) {
		StartWindow sw = new StartWindow();
		sw.setVisible(true);
		
	}
}