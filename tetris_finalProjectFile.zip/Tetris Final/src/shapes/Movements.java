package shapes;

public enum Movements {
	DOWN, LEFT, RIGHT, ROTATION, PAUSE;
}
