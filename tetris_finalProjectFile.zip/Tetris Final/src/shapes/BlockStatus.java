package shapes;

public enum BlockStatus {
	ACTIVE, PASSIVE, EMPTY, BORDER;
}
